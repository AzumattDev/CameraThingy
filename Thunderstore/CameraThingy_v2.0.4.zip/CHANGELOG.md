> ### v2.0.4
> - Update for Seelenquell for the Bog Witch patch.
> ### v2.0.3
> - Courtesy Update for Valheim 0.217.46. Just bumping the version and updating the last updated date. Nothing to see here.
> ### v2.0.2
> - Update for Valheim 0.217.22
> ### v2.0.1
> - Update ServerSync internally
> ### v2.0.0
> - Save the rotation and yaw of the camera
> - Changes to how the camera saves in general
> - Update README
> ### v1.0.0
> - Initial Release